# metadata.jpmag.net
JPMAG.NET JAV scraper for KODI


JAV Movie scraper for KODI


first, install https://github.com/JPMAGNET/metadata.common.jpmag.net, 
and after install this.

Sign up, Login is http://jpmag.net

